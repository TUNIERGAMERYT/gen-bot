# Account-Generator-Bot-Discord
An Open Source Account Generator Bot! 



How it works:
Put your Discord Bot Token in Config,
Make sure you have Node.js installed.

You can add accounts in the /Accounts folder,
For Help/Qeustions please join our Discord Server,
Or add me on Discord!

Discord: CosmicHarry#6969
Server: https://discord.gg/45pmz9j9ud

Note: This is my first Discord Bot,
I am new to Javascript and Discord.js!
